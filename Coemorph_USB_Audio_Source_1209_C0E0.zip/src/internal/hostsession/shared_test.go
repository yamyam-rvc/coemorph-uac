package hostsession

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"
	"virtualcables/internal/vhci"
)

type sharedTransport struct {
	*fakeTransport
	change func(*vhci.Device)
}

func (c *sharedTransport) AttachLocalOnce(ctx context.Context, bus string, low bool) (uint32, error) {
	p, e := c.fakeTransport.AttachLocalOnce(ctx, bus, low)
	c.devices[len(c.devices)-1].Vendor = 0x1209
	c.devices[len(c.devices)-1].Product = 0xc0e0
	if c.change != nil {
		c.change(&c.devices[len(c.devices)-1])
	}
	return p, e
}

func TestSharedSessionOwnershipAndCleanup(t *testing.T) {
	for _, mode := range []string{"normal", "interrupted", "preexisting", "foreign", "old-shared", "override", "lowlatency", "detachfailure"} {
		t.Run(mode, func(t *testing.T) {
			tr, s, f := fixtures()
			c := &sharedTransport{fakeTransport: f}
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			switch mode {
			case "interrupted":
				f.attachError = errors.New("interrupted reply")
			case "preexisting":
				d := cable()
				d.Vendor = 0x1209
				d.Product = 0xc0e0
				f.devices = []vhci.Device{d}
			case "foreign":
				c.change = func(d *vhci.Device) { d.Product = 0x27df }
			case "old-shared":
				c.change = func(d *vhci.Device) { d.Vendor = 0x16c0; d.Product = 0x27e0 }
			case "override":
				c.change = func(d *vhci.Device) { d.SerialOverride = "foreign" }
			case "lowlatency":
				c.change = func(d *vhci.Device) { d.LowLatency = true }
			case "detachfailure":
				f.detachError = errors.New("detach rejected")
			}
			attached := false
			err := RunSharedAudio(ctx, c, s, func(d vhci.Device) error { attached = true; cancel(); return nil })
			if mode == "normal" && (err != nil || !attached || len(f.devices) != 0) {
				t.Fatalf("normal: %v %v %v", err, attached, f.devices)
			}
			if mode != "normal" && err == nil {
				t.Fatal("failure accepted")
			}
			if mode == "interrupted" && (len(f.devices) != 0 || attached) {
				t.Fatal("interrupted attachment not reconciled")
			}
			if mode == "preexisting" || mode == "foreign" || mode == "old-shared" || mode == "override" || mode == "lowlatency" {
				if attached || strings.Contains(strings.Join(tr.events, ","), "detach") {
					t.Fatalf("foreign adoption/detach: %v", tr.events)
				}
			}
			if mode == "normal" || mode == "interrupted" {
				events := strings.Join(tr.events, ",")
				if !strings.Contains(events, "detach,list,drained,closed") {
					t.Fatal(events)
				}
			}
		})
	}
}
