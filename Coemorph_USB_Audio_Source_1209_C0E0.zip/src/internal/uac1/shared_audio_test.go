package uac1

import (
	"bytes"
	"encoding/binary"
	"testing"
	"virtualcables/internal/identity"
)

func TestSharedAudioIdentityAndUnchangedTopology(t *testing.T) {
	serial := identity.SerialPrefix + "COEMORPH-0123456789ABCDEF0123456789ABCDEF-001"
	d, err := NewSharedAudioDevice(250, serial)
	if err != nil {
		t.Fatal(err)
	}
	old, err := NewUAC2DeviceWithSerial(1, 250, serial)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(d.Descriptors.Config, old.Descriptors.Config) {
		t.Fatal("audio topology changed")
	}
	if !bytes.Equal(d.Descriptors.Device[:8], old.Descriptors.Device[:8]) || !bytes.Equal(d.Descriptors.Device[12:], old.Descriptors.Device[12:]) {
		t.Fatal("non-ID device bytes changed")
	}
	if binary.LittleEndian.Uint16(d.Descriptors.Device[8:10]) != 0x1209 || binary.LittleEndian.Uint16(d.Descriptors.Device[10:12]) != 0xc0e0 {
		t.Fatal("wrong shared ID")
	}
	if binary.LittleEndian.Uint16(old.Descriptors.Device[8:10]) != 0xffff || binary.LittleEndian.Uint16(old.Descriptors.Device[10:12]) != 0xca01 {
		t.Fatal("lab ID changed")
	}
	if d.Descriptors.Product != "Coemorph" || !bytes.Equal(d.Descriptors.Strings[2], stringDescriptor("Coemorph")) {
		t.Fatal("wrong visible name")
	}
	if !bytes.Equal(d.Descriptors.Strings[3], stringDescriptor(serial)) || !bytes.Equal(d.Descriptors.Strings[0], []byte{6, 3, 9, 4, 17, 4}) {
		t.Fatal("missing serial or English language")
	}
}

func TestSharedAudioRejectsForeignOrMalformedNamespace(t *testing.T) {
	suffix := "COEMORPH-0123456789ABCDEF0123456789ABCDEF-001"
	for _, s := range []string{suffix, "other@example.com:" + suffix, "x" + identity.SerialPrefix + suffix, "yamyamXrvc@gmailXcom:" + suffix, identity.SerialPrefix + suffix + "\n", identity.SerialPrefix + suffix + " -other", identity.SerialPrefix + "COEMORPH-0123456789abcdef0123456789abcdef-001"} {
		if _, err := NewSharedAudioDevice(250, s); err == nil {
			t.Fatalf("accepted %q", s)
		}
	}
}
