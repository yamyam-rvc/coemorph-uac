package uac1

import (
	"encoding/binary"
	"fmt"
	"virtualcables/internal/identity"
)

// NewSharedAudioDevice changes identity only; topology, PCM and timing remain
// those of the existing UAC2 implementation. Lab constructors stay unchanged.
func NewSharedAudioDevice(latencyMS int, serial string) (*Device, error) {
	if !identity.ValidSerial(serial) {
		return nil, fmt.Errorf("invalid shared Audio installation serial")
	}
	d, err := NewUAC2DeviceWithSerial(1, latencyMS, serial)
	if err != nil {
		return nil, err
	}
	binary.LittleEndian.PutUint16(d.Descriptors.Device[8:10], identity.Vendor)
	binary.LittleEndian.PutUint16(d.Descriptors.Device[10:12], identity.Product)
	d.Descriptors.Product = identity.DisplayName
	d.Descriptors.Strings[2] = stringDescriptor(identity.DisplayName)
	return d, d.Descriptors.Validate()
}
