package vhci

import "testing"

// Exercise the production predicate used by both attachment reconciliation
// and DetachVerified. A VID-only or PID-only migration must not pass.
func TestAllocatedIdentityRejectsOtherAllocations(t *testing.T) {
	for _, tt := range []struct {
		name     string
		vid, pid uint16
		want     bool
	}{
		{"allocated", 0x1209, 0xc0e0, true},
		{"old-shared", 0x16c0, 0x27e0, false},
		{"old-lab", 0xffff, 0xca01, false},
		{"vendor-only-migration", 0x1209, 0x27e0, false},
		{"product-only-migration", 0x16c0, 0xc0e0, false},
		{"other-pidcodes-project", 0x1209, 0xc0e1, false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			d := Device{Port: 1, Host: "127.0.0.1", Service: "3240", BusID: "1-1", Vendor: tt.vid, Product: tt.pid}
			if got := d.IsLocalSharedAudioCable(); got != tt.want {
				t.Fatalf("identity accepted=%v, want %v", got, tt.want)
			}
		})
	}
}
