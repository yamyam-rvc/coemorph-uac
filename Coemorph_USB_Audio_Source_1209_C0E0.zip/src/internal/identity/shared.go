// Package identity defines the pid.codes allocation for Coemorph USB Audio.
// Allocation: https://github.com/pidcodes/pidcodes.github.com/pull/1287
// This allocation is not USB-IF certification. Existing installation serials
// remain unchanged; the email prefix is retained for identity continuity.
package identity

import "regexp"

const (
	Vendor       uint16 = 0x1209
	Product      uint16 = 0xc0e0
	SerialPrefix        = "yamyam.rvc@gmail.com:"
	DisplayName         = "Coemorph"
)

var serialPattern = regexp.MustCompile(`^yamyam\.rvc@gmail\.com:COEMORPH-[0-9A-F]{32}-001$`)

// ValidSerial requires both the developer namespace and the full installation ID.
func ValidSerial(serial string) bool { return serialPattern.MatchString(serial) }
