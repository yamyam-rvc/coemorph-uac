# Coemorph USB Audio

This USB component and its Coemorph modifications are BSD-2-Clause.
The original notices are retained in the accompanying license files.
The separate Coemorph voice-conversion application and model weights are
not part of this source archive.

The Windows host exposes a 48 kHz stereo, 16-bit PCM UAC2 playback/capture
pair named Coemorph through localhost USB/IP and an installed signed
usbip-win2 transport. USB allocation: 1209:C0E0, accepted in
https://github.com/pidcodes/pidcodes.github.com/pull/1287 .
This is an ID allocation, not USB-IF certification.

Build on Windows with Go 1.26.5 and CGO_ENABLED=0, from src:

    go test ./...
    go vet ./...
    go build -trimpath -buildvcs=false -o CoemorphUACHost.exe ./cmd/coemorph-uac-host

The host requires redirected stdin as its lifetime lease and an explicit
serial: -serial yamyam.rvc@gmail.com:COEMORPH-<32 uppercase hex digits>-001
Use each installation's persistent random identifier. Pipe EOF initiates
owned-device detach and server drain. This component is not an installer.

Some internal names contain Shared for compatibility with the earlier
shared-ID implementation; the product host now uses 1209:C0E0.
Historical lab commands retain FFFF:CA01 and are not product entry points.

Source hashes are in SOURCE_MANIFEST.json. BUILD_VALIDATION.json identifies
the tested component binary. Component tests passed; final integration,
installation/update, cold restart and end-to-end latency tests remain pending.
The older UAC1 timestamp issue remains unresolved; it is not a claim of a
defect in usbip-win2 or a demonstrated UAC1 fix.

The public repository's earlier snapshot is
https://github.com/yamyam-rvc/coemorph-uac/tree/4562aada25ea3c99d42197d55ddd4d9628ede3c9 .
This archive includes later identity and ownership changes and is the
corresponding source for the binary identified in BUILD_VALIDATION.json.
